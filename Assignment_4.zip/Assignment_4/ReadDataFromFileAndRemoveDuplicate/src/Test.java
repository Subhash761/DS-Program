import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;

public class Test {
	public static void main(String[] args) throws Exception {
		File file = new File("C:\\Users\\PiKay\\Desktop\\Test.txt");
		ArrayList dupArray = new ArrayList<>();
		HashMap<String, String> t = new HashMap<String, String>();
		TreeSet<String> t1 = new TreeSet<String>();
		BufferedReader br = new BufferedReader(new FileReader(file));
		String str;

		while ((str = br.readLine()) != null) {
			// System.out.println(str);
			t1.add(str);
		}
		// System.out.println(t1);
		int SIZE = t1.size();
		String a[] = new String[SIZE];

		int count = 0;
		Iterator<String> it = t1.iterator();
		while (it.hasNext()) {
			a[count] = (String) it.next();
			count++;
		}
		
		for (int i = 0; i < a.length; i++) 
		{
			dupArray.add(a[i]);
			System.out.println(a[i]);
		}
		
		String ss1 = null;
		String ss2 = null;
		String ss3 = null;
		String ss4 = null;
		ArrayList al = new ArrayList();
		for (int j = 0; j < a.length; j++) {
			for (int k = j + 1; k < a.length; k++) {
				StringTokenizer stt1 = new StringTokenizer(a[j], ",");
				while (stt1.hasMoreElements()) {
					ss1 = (String) stt1.nextElement();
					ss2 = (String) stt1.nextElement();
					StringTokenizer stt2 = new StringTokenizer(a[k], ",");
					while (stt2.hasMoreElements()) {
						ss3 = (String) stt2.nextElement();
						ss4 = (String) stt2.nextElement();
						if (ss1.equals(ss4) && ss2.equals(ss3)) {
							// System.out.println("---copy of index "+j+"----- found at place---"+k+"");
							//System.out.println(a[j]);
							al.add(a[k]);
						}
					}
				}
			}
		}
		
		dupArray.removeAll(al);
		System.out.println();
		System.out.println("Duplicate is removed--");
		System.out.println();
		for (int i = 0; i < dupArray.size(); i++) 
		{
			System.out.println(dupArray.get(i));
		}
	}
}
