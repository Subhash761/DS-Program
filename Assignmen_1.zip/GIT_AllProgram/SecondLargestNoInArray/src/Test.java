
public class Test
{
	public static void main(String[] args) {
		int arr[] = { 12, 35, 1, 10, 34, 1 };
		int n = arr.length;
		printSecondlargest(arr, n);
}

	public static void printSecondlargest(int arr[], int n) {
		if (n < 2)
		{
			System.out.print(" Invalid Input ");
			return;
		}
		int firstBiggest=0;
		int secondBiggest = 0;
		for (int  i = 0; i < n; i++)
		{
			 firstBiggest = arr[0];
			 secondBiggest = arr[1];
			if (arr[i] > firstBiggest) 
			{
				secondBiggest = firstBiggest;
				firstBiggest = arr[i];
			}
			else 
			if(arr[i] > secondBiggest && arr[i] != firstBiggest)
			{
				secondBiggest = arr[i];
			}
		}
		System.out.print("The second largest element" + " is " + secondBiggest);
	}
}
