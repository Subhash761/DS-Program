
public class SubArraySum 
{
	public static void main(String[] args) 
	{ 
		int arr[] = {15, 2, 4, 8, 9, 5, 10, 23}; 
		int n = arr.length; 
		int sum = 23; 
		subArrSum(arr, n, sum); 
	} 
		static int subArrSum(int arr[], int n, int sum) 
		{ 
			int csum, i, j; 
			for (i = 0; i < n; i++) 
			{ 
				csum = arr[i]; 
				for (j = i + 1; j <= n; j++) 
				{ 
					if (csum == sum) 
					{ 
						System.out.println("Sum found between indexes " + i + " and " + (j-1)); 
						return 1; 
					} 
					if (csum > sum || j == n) 
						break; 
					csum = csum + arr[j]; 
				} 
			} 

			System.out.println("No subarray found"); 
			return 0; 
		} 

	} 

