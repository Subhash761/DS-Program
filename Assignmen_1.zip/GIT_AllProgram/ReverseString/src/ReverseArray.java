
public class ReverseArray 
{
public static void main(String[] args) 
{
	String s = "pikay"; 
	reverseString(s);
}

 static void reverseString(String s) 
 {
	 char[] Arr = s.toCharArray(); 

		for (int i= Arr.length-1;i>=0;i--) 
			System.out.print(Arr[i]); 
	} 
	
}
