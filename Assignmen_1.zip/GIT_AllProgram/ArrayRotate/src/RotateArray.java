
import java.util.*;
import java.lang.*;
import java.io.*;

class RotateArray {
	public static void main(String[] args) {
		RotateArray rotate = new RotateArray();
		int arr[] = { 1, 2, 3, 4, 5, 6, 7 };
		rotate.leftRotate(arr, 2, 7);

	}

	void leftRotate(int arr[], int d, int n) 
	{
		int[] arr1 = new int[14];

		for (int i = 0; i < arr.length; i++) {
			arr1[i] = arr[i];
		}
		int j=0;
		for (int i = arr.length; i < arr1.length; i++) 
		{
			arr1[i] = arr[j];
			j++;
		}
		for (int i = d; i < arr.length+d; i++) 
		{
			System.out.print(" "+arr1[i]);
		}
	}

}
