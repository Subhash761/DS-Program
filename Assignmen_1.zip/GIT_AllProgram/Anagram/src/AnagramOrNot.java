import java.util.Arrays;

public class AnagramOrNot 
{
	public static void main(String args[]) 
	{ 
		String s1="pikay";
		String s2="yakip";
		boolean b=findAnagram(s1, s2);
		if (b) 
			System.out.println("anagram of each other"); 
		else
			System.out.println("not anagram of each other"); 
	} 
	
		static boolean findAnagram(String s1, String s2) 
		{ 
			if (s1.length() !=s2.length()) 
				return false; 
			
			char  [] str1=s1.toCharArray();
			char  [] str2=s2.toCharArray();
			Arrays.sort(str1); 
			Arrays.sort(str2); 

			for (int i = 0; i < s1.length(); i++)
			{
				if (str1[i] != str2[i]) 
				{
					return false; 
				}
			}
			return true; 
		} 
	} 

